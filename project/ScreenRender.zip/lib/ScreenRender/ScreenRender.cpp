#include "ScreenRender.h"
#include "Adafruit_NeoPixel.h"

ScreenRender::ScreenRender(size_t pin, size_t height, size_t width)
    : height_(height)
    , width_(width)
    , objects()
    , num_players_(0)
    , brightness_(255)
    , matrix_(Adafruit_NeoPixel(height * width, pin))
    , shift_val_(0) {
    memset(objects, 0, kMaxPlayers * sizeof(PlayerPixel));
    matrix_.begin();
}

void ScreenRender::UpdateScreen() {
    ProcessColours();
    matrix_.fill(0, 0, height_ * width_);
    for (int i = 0; i < num_players_; i++) {
        matrix_.setPixelColor(objects[i].row * 8 + objects[i].col, objects[i].r, objects[i].g, objects[i].b);
    }
    matrix_.show();
}

void ScreenRender::SetColourShift(int colorval) { shift_val_ = colorval; }

int ScreenRender::AddPlayer(PlayerPixel player) {
    if (num_players_ >= kMaxPlayers) {
        return -1;
    }
    int idx = num_players_;
    objects[num_players_] = player;
    num_players_++;
    return idx;
}

int ScreenRender::SetPlayerPosition(uint8_t id, uint8_t row, uint8_t col) {
    if (id >= kMaxPlayers) {
        return -1;
    }

    if (row < height_) {

        objects[id].row = row;
    } else {
        return -1;
    }
    if (row < width_) {
        objects[id].col = col;
        return id;
    }
    return -1;
}

void ScreenRender::SetBrightness(int brightness) { brightness = brightness & 0xff; }

void ScreenRender::ProcessColours() {
    for (int i = 0; i < num_players_; i++) {
        objects[i].r = (uint8_t)((float)(brightness_ / 255.0) * objects[i].r);
        objects[i].g = (uint8_t)((float)(brightness_ / 255.0) * objects[i].g);
        objects[i].b = (uint8_t)((float)(brightness_ / 255.0) * shift_val_);
    }
}
